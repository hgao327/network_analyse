// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#pragma once
#include "ebpf_api.h"
#include "ebpf_result.h"

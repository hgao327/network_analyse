// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT
#pragma once

#include <windows.h>
#include <ctype.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

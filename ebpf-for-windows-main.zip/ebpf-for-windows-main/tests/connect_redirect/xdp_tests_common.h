// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#pragma once

#include <stdint.h>

#define REFLECTION_TEST_PORT 8989

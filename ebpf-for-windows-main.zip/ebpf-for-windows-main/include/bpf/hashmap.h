// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT
#pragma once
#pragma warning(push)
#include "../external/bpftool/libbpf/src/hashmap.h"
#pragma warning(pop)

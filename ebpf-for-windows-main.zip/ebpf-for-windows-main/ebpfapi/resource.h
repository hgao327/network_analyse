// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#define EBPF_FILE_DESCRIPTION "eBPF For Windows User API"
#define EBPF_FILE_NAME "ebpfapi.dll"

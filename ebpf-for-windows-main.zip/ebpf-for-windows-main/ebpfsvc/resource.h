// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#define EBPF_FILE_DESCRIPTION "eBPF For Windows Service"
#define EBPF_FILE_NAME "ebpfsvc.exe"

// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#define EBPF_FILE_DESCRIPTION "eBPF Network Extension"
#define EBPF_FILE_NAME "netebpfext.sys"

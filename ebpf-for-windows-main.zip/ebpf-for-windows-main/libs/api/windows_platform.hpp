// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT
#pragma once

extern const ebpf_platform_t g_ebpf_platform_windows;

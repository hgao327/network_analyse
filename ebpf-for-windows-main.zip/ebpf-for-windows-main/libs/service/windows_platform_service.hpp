// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#pragma once

#include "windows_platform_common.hpp"

extern const ebpf_platform_t g_ebpf_platform_windows_service;

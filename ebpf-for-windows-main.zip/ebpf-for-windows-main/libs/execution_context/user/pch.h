// Copyright (c) eBPF for Windows contributors
// SPDX-License-Identifier: MIT

#pragma once

// add headers that you want to pre-compile here
#include "framework.h"
